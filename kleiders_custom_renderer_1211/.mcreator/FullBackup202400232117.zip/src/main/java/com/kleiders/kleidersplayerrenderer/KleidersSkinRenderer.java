/*
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside com.kleiders.kleidersplayerrenderer as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package com.kleiders.kleidersplayerrenderer;

import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.model.PlayerModel;

import javax.annotation.Nullable;

@OnlyIn(Dist.CLIENT)
public class KleidersSkinRenderer extends PlayerRenderer implements KleidersIgnoreCancel {
	private final ResourceLocation PLAYER_SKIN;

	public KleidersSkinRenderer(EntityRendererProvider.Context context, boolean useSmallArms, ResourceLocation skin) {
		super(context, useSmallArms);
		PLAYER_SKIN = skin;
	}

	public void clearLayers() {
		this.layers.clear();
	}

	public ResourceLocation getTextureLocation(AbstractClientPlayer p_117783_) {
		return PLAYER_SKIN;
	}

	@Override
	@Nullable
	protected RenderType getRenderType(AbstractClientPlayer p_115322_, boolean p_115323_, boolean p_115324_, boolean p_115325_) {
		ResourceLocation resourcelocation = this.getTextureLocation(p_115322_);
		return RenderType.entityTranslucentCull(resourcelocation);
	}

	public static void hidePlayerModelPiece(PlayerModel model, int piece) {
		switch (piece) {
			case 0 :
				model.hat.visible = false;
				break;
			case 1 :
				model.jacket.visible = false;
				break;
			case 2 :
				model.leftPants.visible = false;
				break;
			case 3 :
				model.rightPants.visible = false;
				break;
			case 4 :
				model.leftSleeve.visible = false;
				break;
			case 5 :
				model.rightSleeve.visible = false;
				break;
			case 6 :
				model.head.visible = false;
				break;
			case 7 :
				model.body.visible = false;
				break;
			case 8 :
				model.leftLeg.visible = false;
				break;
			case 9 :
				model.rightLeg.visible = false;
				break;
			case 10 :
				model.leftArm.visible = false;
				break;
			case 11 :
				model.rightArm.visible = false;
				break;
			default :
				break;
		}
	}
}
